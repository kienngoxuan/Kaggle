# JanuaryKaggle
I use this repository for tracking my model performance on Kaggle
I also use this to track my progess
